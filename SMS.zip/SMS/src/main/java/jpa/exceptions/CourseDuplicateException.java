package jpa.exceptions;

public class CourseDuplicateException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CourseDuplicateException(String errorMessage) {
        super(errorMessage);
    }
}
