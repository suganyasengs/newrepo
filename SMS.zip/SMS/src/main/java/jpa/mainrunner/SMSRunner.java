/*
 * Filename: SMSRunner.java
 * Author: Suganya
 * 02/24/2023 
 */
package jpa.mainrunner;

import static java.lang.System.out;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import jpa.entitymodels.Course;
import jpa.entitymodels.Student;
import jpa.exceptions.CourseDuplicateException;
import jpa.service.CourseService;
import jpa.service.StudentCourseService;
import jpa.service.StudentService;


/**
 * 
 * @author Suganya
 *
 */
public class SMSRunner {

	private Scanner sin;
	private StringBuilder sb;

	private CourseService courseService;
	private StudentService studentService;
	private Student currentStudent;
	private StudentCourseService scService;
	
	 

	public SMSRunner() {
		sin = new Scanner(System.in);
		sb = new StringBuilder();
		courseService = new CourseService();
		studentService = new StudentService();
		scService = new StudentCourseService();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		SMSRunner sms = new SMSRunner();
		sms.run();
	}

	private void run() {
		// Login or quit
		switch (menu1()) {		
		case 1:
			if (studentLogin()) {
				registerMenu();
			}
			break;
		case 2:
			out.println("Goodbye!");
			break;

		default:
			out.println("Your selection is invalid. Goodbye!");			
			break;
		}
	}

	private int menu1() {
		sb.append("-------------------");
		sb.append("\n1. Student Login\n2. Quit Application\n");
		sb.append("-------------------\n");
		sb.append("Please enter your selection:");
		out.print(sb.toString());
		sb.delete(0, sb.length());
		int option=0;
		try {
			option=sin.nextInt();
		}
		catch(InputMismatchException e) {
			out.println("\n You entered an invalid input \n");
		}
		return option;
	}

	private boolean studentLogin() {
		boolean retValue = false;
		out.print("Enter your email address: ");
		String email = sin.next();
		out.print("Enter your password: ");
		String password = sin.next();
		Student student = studentService.getStudentByEmail(email);
		currentStudent = student;		
		if(student==null) {
			out.println("User Validation failed. GoodBye!");
		}
		else if (currentStudent != null & currentStudent.getsPass().equals(password)) {
			List<Course> courses = scService.getAllStudentCourses(email);
			
			if(courses.size()==0) {
				out.println("You have not registered to any courses yet. Do you want to register for new courses?");
			}
			else {
				out.println("Below are all the courses you have registered to.");
				out.printf("%5s %-35s %-35s\n", "ID", "Course", "Instructor");
				for (Course course : courses) {
					//out.println(course);
					 out.printf("%5s %-35s %-35s\n", course.getcId(), course.getcName(), course.getcInstructorName());
				}
				out.println();
			}
			
			retValue = true;
		} else {
			out.println("User Validation failed. GoodBye!");
		}
		return retValue;
	}

	private void registerMenu() {
		sb.append("\n1.Register a class\n2. Logout\nPlease Enter Selection: ");
		out.print(sb.toString());
		sb.delete(0, sb.length());

		switch (sin.nextInt()) {
		case 1:
			List<Course> allCourses = courseService.getAllCourses();
			List<Course> studentCourses = scService.getAllStudentCourses(currentStudent.getsEmail());
			allCourses.removeAll(studentCourses);
			out.printf("%5s %-35s %-35s\n", "ID", "Course", "Instructor");
			for (Course course : allCourses) {
				//out.println(course);
				 out.printf("%5s %-35s %-35s\n", course.getcId(), course.getcName(), course.getcInstructorName());
			}
			out.println();
			out.print("Enter Course Number: ");
			int number = sin.nextInt();
			Course newCourse = courseService.getCourseById(number);
			if (newCourse != null) {
				try {
					scService.registerStudentToCourse(currentStudent.getsEmail(), newCourse.getcId());
				}
				catch(CourseDuplicateException e) {
					out.println("You are already registered in that course!");
				}
				Student temp = studentService.getStudentByEmail(currentStudent.getsEmail());



				//StudentCourseService scService = new StudentCourseService();
				List<Course> sCourses = scService.getAllStudentCourses(temp.getsEmail());


				out.println("You have been registered to all the below courses:");
				out.printf("%5s %-35s %-35s\n", "ID", "Course", "Instructor");
				for (Course course : sCourses) {
					//out.println(course);
					 out.printf("%5s %-35s %-35s\n", course.getcId(), course.getcName(), course.getcInstructorName());
				}
				out.println();
				
				out.println("You have been signed out. Goodbye!");
			}
			break;
		case 2:
		default:
			out.println("Goodbye!");
		}
	}
}
