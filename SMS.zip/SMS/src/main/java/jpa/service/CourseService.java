package jpa.service;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import jakarta.persistence.Query;
import jpa.dao.CourseDAO;
import jpa.entitymodels.Course;

public class CourseService implements CourseDAO {
	final SessionFactory sessionFactory = new Configuration()
			.configure("hibernate.cfg.xml")
			.addAnnotatedClass(Course.class)
			.buildSessionFactory();
	final Session session = sessionFactory.openSession();

	/**
	 * @return a list of all courses available.
	 */
	public List<Course> getAllCourses() {
		Query query = session.createQuery("SELECT c FROM Course c",null);
		List<Course> courses = query.getResultList();
		return courses;
	}

	/** Returns the course with the specified ID.
	 *
	 * @param id the ID of the course to retrieve.
	 * @return the course with the specified ID, or null if no course with that ID exists.
	 */
	public Course getCourseById(int id) {
		Query query = session.createQuery("from Course c where cId = :cid",null);
		query.setParameter("cid", id);
		return (Course) query.getSingleResult();
	}

}
