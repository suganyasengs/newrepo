package jpa.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import jakarta.persistence.Query;
import jpa.entitymodels.Course;
import jpa.entitymodels.StudentCourses;
import jpa.exceptions.CourseDuplicateException;

public class StudentCourseService {

	final SessionFactory sessionFactory = new Configuration()
			.configure("hibernate.cfg.xml")
			.addAnnotatedClass(StudentCourses.class)
			.buildSessionFactory();
	final Session session = sessionFactory.openSession();

	private CourseService courseService;


	/**
	 * Returns all courses registered to a student with the provided email id.
	 * 
	 * @param email
	 * @return Courses
	 */
	public List<Course> getAllStudentCourses(String email) {
		Query query = session.createNamedQuery("CoursesByStudent",null);
		query.setParameter("email", email);
		List<StudentCourses> scs = query.getResultList();
		List<Course> courses=new ArrayList();
		courseService = new CourseService();

		for(StudentCourses sc: scs) {
			courses.add(courseService.getCourseById(sc.getCourseID()));
		}

		return courses;
	}

	/**
	 * Register course to the student email.
	 * @param email		email of the student
	 * @param courseId	course-id of the course to be registered
	 * @return boolean 		status of the registration
	 * @throws CourseDuplicateException throws the course duplicate exception if student has already registered.
	 */
	public boolean registerStudentToCourse(String email, int courseId) throws CourseDuplicateException{

		boolean status = false;
		try {
			// Check if student is already registered for the course
			Query query = session.createQuery("SELECT COUNT(*) FROM StudentCourses WHERE eMail = :email AND courseID = :courseId",null);
			query.setParameter("email", email);
			query.setParameter("courseId", courseId);
			Long count = (Long) query.getSingleResult();

			if (count > 0) {
				throw new CourseDuplicateException("Course already registered");
			} else {

				StudentCourses sc = new StudentCourses(email, courseId);
				session.beginTransaction();
				session.persist(sc);
				session.getTransaction().commit();
				status = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		}

		return status;
	}
}