package jpa.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import jakarta.persistence.NoResultException;
import jakarta.persistence.Query;
import jpa.dao.StudentDAO;
import jpa.entitymodels.Course;
import jpa.entitymodels.Student;

public class StudentService implements StudentDAO {
	final SessionFactory sessionFactory = new Configuration()
			.configure("hibernate.cfg.xml")
			.addAnnotatedClass(Student.class)
			.buildSessionFactory();
	final Session session = sessionFactory.openSession();



	/**

	 * Retrieves a list of all students in the database.
	 *
	 * @return a List of Student objects representing all students.
	 */

	public List<Student> getAllStudents() {

		Query query = session.createQuery("SELECT s FROM Student s",null);
		List<Student> students = query.getResultList();
		return students;
	}
	/**
	 * Returns the student object with the specified email address,
	 *  or null if the email address is not found.
	 * @param the email address of the student to retrieve.
	 * @return the Student object with the specified email address, or null if not found.
	 */


	public Student getStudentByEmail(String email) {
		Student student =null;

		try {


			Query query = session.createQuery("FROM Student s where s.sEmail=:e",null);
			query.setParameter("e", email);
			student= (Student) query.getSingleResult();
		}
		catch(NoResultException e) {

		}

		return student;

	}

	/**
	 * Validates the student credentials for the specified email and password.
	 *
	 * @param email the email address of the student to validate.
	 * @param password the password of the student to validate.
	 * @return true if the email and password are valid, false otherwise.
	 */
	public boolean validateStudent(String email, String password) {
		boolean login = false;
		String query = "SELECT email, password FROM Student where sEmail= :email AND sPassword = :password";
		Query q = session.createQuery(query,null);
		q.setParameter("email",email);
		q.setParameter("password", password);
		if (q.getResultList() !=null) {
			login=true;
		}
		return login;
	}

	/**
	 * Registers the student with the specified email to the course with the specified ID.
	 *
	 * @param email the email address of the student to register.
	 * @param courseId the ID of the course to register the student to.
	 * @return true if the student was successfully registered to the course, false otherwise.
	 */
	public boolean registerStudentToCourse(String email, int courseId) {
		/*
		boolean login = false;
		String query = "SELECT sEmail, sCourseId FROM Student where sEmail= :email AND sCourseId = :courseId";
		Query q = session.createQuery(query,null);
		q.setParameter("email",email);
		q.setParameter("courseId", courseId);
		if (q.getResultList() !=null) {
			login=true;
		}
		return login;
		 */

		boolean status = false;
		try {
			Student student1;
			CourseService courseService= new CourseService();
			Course course1=courseService.getCourseById(courseId);
			student1 = getStudentByEmail(email);

			if(student1.getsCourses().contains(course1)) {
				status = false;

			}
			else {

				student1.getsCourses().add(course1);
			}

			session.beginTransaction();
			session.persist(student1);
			session.getTransaction().commit();


			status = true;
		}
		catch(Exception e) {
			System.out.println("Student already registered in the course");
		}
		//session.close();

		return status;
	}

	/**
	 * Returns a list of courses that the student with the specified email is registered for.
	 *
	 * @param email the email address of the student to retrieve courses for.
	 * @return a list of courses that the student with the specified email is registered for.
	 */
	public List<Course> getStudentCourses(String email) {
		/*Student s=getStudentByEmail(email);
		return s.getsCourses();
		/*
		Query query = session.createQuery("SELECT  FROM Course c join StudentCourses s on c.cId=s.courseID "
				+ " where s.eMail=:e",null);
		query.setParameter("e", email);
        List<Course> courses = query.getResultList();
        return courses;
		 */
		Student student = getStudentByEmail(email);
		if (student != null) {
			return student.getsCourses();
		} else {
			return new ArrayList<Course>(); // return an empty list if student is null
		}
	}

}
