package jpa.service;

import org.junit.Before;
import org.junit.jupiter.api.Test;

import jpa.entitymodels.Course;
import jpa.entitymodels.Student;
import junit.framework.TestCase;

public class StudentServiceTest extends TestCase{

	Student student1;
	StudentService studentService;
	StudentCourseService studentCourseService;
	CourseService courseService;
	Course course1;

	@Override
	@Before
	public void setUp() throws Exception {


		studentService=new StudentService();
		courseService = new CourseService();
		studentCourseService = new StudentCourseService();
		
		course1 = courseService.getCourseById(1);
		student1 = studentService.getStudentByEmail("hluckham0@google.ru");
		
		
		

	}


	@Test
	public void testGetStudentByEmail() {
		assertEquals("hluckham0@google.ru",studentService.getStudentByEmail("hluckham0@google.ru").getsEmail());
	}

	@Test
	public void testGetAllStudents() {
		assertEquals(10,studentService.getAllStudents().size());
	}
	
	
	
	
	@Test
	public void testRegisterStudentToCourse() {
		try {
		assertEquals(true,studentCourseService.registerStudentToCourse("hluckham0@google.ru",1));
		}
		catch(Exception e) {
			System.out.println("Error");
		}
	}
	
	@Test
	public void testGetStudentCourses() {
		assertEquals(1,studentCourseService.getAllStudentCourses("hluckham0@google.ru").size());
	}



}
